# TCC
Código de desenvolvimento para análise dinâmica de um protótipo com suspensão do tipo duplo A, através de dados advindos de sensores
